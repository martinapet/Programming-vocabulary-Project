from flask import Flask, render_template
app = Flask(__name__)

# two decorators, same function
@app.route('/')
@app.route('/homepageindex.html')
def index():
    return render_template('homepageindex.html', the_title='Почетна')

@app.route('/lekcii.html')
def lekcii():
    return render_template('lekcii.html', the_title='Лекции')

@app.route('/introduction.html')
def introduction():
    return render_template('introduction.html', the_title='Вовед')
	
@app.route('/programming.html')
def programming():
    return render_template('programming.html', the_title='Што е програмирање?')
	
@app.route('/programs.html')
def programs():
    return render_template('programs.html', the_title='Програми')
	
@app.route('/think.html')
def think():
    return render_template('think.html', the_title='Мисли како компјутер')

@app.route('/games.html')
def games():
    return render_template('games.html', the_title='Видео игри')
	
@app.route('/testovi.html')
def testovi():
    return render_template('testovi.html', the_title='Тестови')
	
@app.route('/quiz1.html')
def quiz1():
    return render_template('quiz1.html', the_title='Тест 1')
	
@app.route('/quiz2.html')
def quiz2():
    return render_template('quiz2.html', the_title='Тест 2')
	
@app.route('/quiz3.html')
def quiz3():
    return render_template('quiz3.html', the_title='Тест 3')
	
@app.route('/quiz4.html')
def quiz4():
    return render_template('quiz4.html', the_title='Тест 4')

@app.route('/quiz5.html')
def quiz5():
    return render_template('quiz5.html', the_title='Тест 5')

if __name__ == '__main__':
    app.run(debug=True, port=80)